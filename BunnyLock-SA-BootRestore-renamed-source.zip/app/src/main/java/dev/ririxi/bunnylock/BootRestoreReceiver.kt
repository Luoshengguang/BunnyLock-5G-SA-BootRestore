package dev.ririxi.bunnylock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import dev.ririxi.bunnylock.modem.ModemController
import dev.ririxi.bunnylock.modem.NetMode
import dev.ririxi.bunnylock.modem.NrMode
import dev.ririxi.bunnylock.modem.RootState
import dev.ririxi.bunnylock.shizuku.RootOrShizuku
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/** Reapplies only SIM 2's RAT and NR mode after boot. It never touches band masks. */
class BootRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED && intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val prefs = context.getSharedPreferences("bunnylock", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("bootRestore5gSa", true)) return

        val pending = goAsync()
        val app = context.applicationContext
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            val controller = ModemController(app, this, RootOrShizuku(app) {})
            try {
                // Let Android finish bringing up telephony and the SIM before opening the privileged helper.
                delay(20_000)
                controller.connect()
                withTimeout(90_000) {
                    controller.state.first { it.root is RootState.Granted || it.root is RootState.Denied }
                }
                if (controller.state.value.root !is RootState.Granted || !controller.helperRunning) {
                    Log.e(TAG, "Boot restore skipped: root/helper unavailable")
                    return@launch
                }

                // BunnyLock stores SIM as a user-facing slot number (1 or 2), not subscriptionId.
                controller.loadSims()
                delay(1_500)
                val sim2Present = controller.state.value.sims.any { it.slot == 1 }
                if (!sim2Present) {
                    Log.e(TAG, "Boot restore skipped: SIM 2 is not active")
                    return@launch
                }
                controller.setSim(2)
                delay(1_500)

                // Apply only the two requested modes. Do not change LTE/NR band locks.
                val ratError = controller.setNetMode(NetMode.NR_ONLY)
                if (ratError != null) Log.e(TAG, "NR_ONLY apply reported: $ratError")
                val nrError = controller.setNrMode(NrMode.SA)
                if (nrError != null) Log.e(TAG, "SA apply reported: $nrError")

                delay(1_000)
                controller.refreshNow()
                val state = controller.state.value
                val ratOk = state.netMode == NetMode.NR_ONLY
                val saOk = state.nrMode == NrMode.SA
                if (ratOk && saOk) {
                    Log.i(TAG, "Boot restore verified: SIM 2 NR_ONLY + SA")
                } else {
                    Log.e(TAG, "Boot restore not verified: netMode=${state.netMode}, nrMode=${state.nrMode}")
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Boot restore failed", t)
            } finally {
                controller.close()
                pending.finish()
                scope.cancel()
            }
        }
    }

    companion object { private const val TAG = "BunnyBootRestore" }
}
