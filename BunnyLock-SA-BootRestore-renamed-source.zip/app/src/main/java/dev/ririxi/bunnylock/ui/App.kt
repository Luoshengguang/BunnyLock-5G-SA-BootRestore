@file:Suppress("FunctionName")

package dev.ririxi.bunnylock.ui

import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingToolbarDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LargeFlexibleTopAppBar
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import dev.ririxi.bunnylock.R
import dev.ririxi.bunnylock.data.Release
import dev.ririxi.bunnylock.modem.Access
import dev.ririxi.bunnylock.modem.RootState
import dev.ririxi.bunnylock.modem.SimInfo
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.milliseconds

private val LIVE_REFRESH_PAUSE = 500.milliseconds

private val RAIL_MIN_WIDTH = 600.dp

private val RAIL_MIN_HEIGHT = 480.dp

private val MAX_CONTENT_WIDTH = 720.dp

enum class Tab(
    @StringRes val label: Int,
    val icon: ImageVector,
) {
    HOME(R.string.shell_tab_home, Icons.Rounded.Home),
    BANDS(R.string.shell_tab_bands, BunnyIcons.Bands),
    CELL(R.string.shell_tab_cell, BunnyIcons.Tower),
    TOOLS(R.string.shell_tab_tools, Icons.Rounded.Build),
    SETTINGS(R.string.shell_tab_settings, Icons.Rounded.Settings),
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun BunnyApp(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableStateOf(Tab.HOME) }
    if (state.modem.root == RootState.Granted && (selectedTab == Tab.HOME || selectedTab == Tab.CELL)) LiveRefresh(vm)
    val snackbar = remember { SnackbarHostState() }
    val appBarStates = Tab.entries.associateWith { rememberTopAppBarState() }
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(appBarStates.getValue(selectedTab))
    val tabStates = rememberSaveableStateHolder()
    LaunchedEffect(Unit) { vm.events.collect { snackbar.showSnackbar(it) } }
    var pulledToRefresh by remember { mutableStateOf(false) }
    LaunchedEffect(state.modem.refreshing) { if (!state.modem.refreshing) pulledToRefresh = false }
    // Refreshes the app starts itself, like the one after every change, show in the app bar so the screen doesn't jump.
    val bunnyRefreshing = state.modem.refreshing && pulledToRefresh
    val showTabs = state.modem.root == RootState.Granted
    val windowSize = LocalWindowInfo.current.containerDpSize
    val showRail = showTabs && windowSize.width >= RAIL_MIN_WIDTH && windowSize.height >= RAIL_MIN_HEIGHT
    val showFloatingBar = showTabs && !showRail
    val floatingBarSpace = if (showFloatingBar) FloatingToolbarDefaults.ContainerSize + FloatingToolbarDefaults.ScreenOffset else 0.dp
    val pendingToolbarSpace = if (selectedTab == Tab.BANDS && state.changedBandCount > 0) PENDING_TOOLBAR_SPACE else 0.dp
    val safeInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)
    val contentSides = if (showRail) WindowInsetsSides.End else WindowInsetsSides.Horizontal
    val layoutDirection = LocalLayoutDirection.current

    state.update?.let { UpdateDialog(it, onSkip = vm::skipUpdate, onDismiss = vm::dismissUpdate) }

    Row(Modifier.fillMaxSize()) {
        if (showRail) {
            TabRail(
                selected = selectedTab,
                onSelect = { selectedTab = it },
                windowInsets = safeInsets.only(WindowInsetsSides.Start + WindowInsetsSides.Vertical),
            )
        }
        Scaffold(
            modifier = Modifier.weight(1f),
            contentWindowInsets = safeInsets.only(contentSides + WindowInsetsSides.Vertical),
            topBar = {
                LargeFlexibleTopAppBar(
                    title = { Wordmark() },
                    subtitle = { Text(topBarSubtitle(state)) },
                    actions = {
                        if (state.modem.settling) TextButton(onClick = vm::stopWaiting, shapes = ButtonDefaults.shapes()) { Text(stringResource(R.string.shell_stop_waiting)) }
                        if (state.modem.sims.size > 1) SimChip(state.modem.sims, state.modem.sim, enabled = !state.busy, onSelect = vm::setSim)
                        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                            when {
                                state.busy || (state.modem.refreshing && !pulledToRefresh) || state.modem.root == RootState.Checking -> {
                                    LoadingIndicator(Modifier.size(36.dp))
                                }

                                state.modem.root == RootState.Granted -> {
                                    IconButton(onClick = vm::refresh, shapes = IconButtonDefaults.shapes()) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = stringResource(R.string.shell_refresh))
                                    }
                                }
                            }
                        }
                    },
                    windowInsets = safeInsets.only(contentSides + WindowInsetsSides.Top),
                    colors =
                        TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                        ),
                    scrollBehavior = scrollBehavior,
                )
            },
            snackbarHost = { SnackbarHost(snackbar, Modifier.padding(bottom = floatingBarSpace + pendingToolbarSpace)) },
        ) { innerPadding ->
            when (val root = state.modem.root) {
                RootState.Checking -> {
                    Centered(innerPadding) {
                        HoppingBunny()
                        Text(state.modem.connectStep, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMediumEmphasized)
                    }
                }

                is RootState.Denied -> {
                    Centered(innerPadding) {
                        DroopyBunny()
                        Text(stringResource(R.string.shell_denied_title), style = MaterialTheme.typography.headlineMediumEmphasized)
                        Text(
                            root.reason,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(onClick = vm::connect, shapes = ButtonDefaults.shapes()) { Text(stringResource(R.string.shell_try_again)) }
                        TextButton(onClick = vm::copyDiagnostics, shapes = ButtonDefaults.shapes()) { Text(stringResource(R.string.common_copy_diagnostics)) }
                    }
                }

                RootState.Granted -> {
                    val pullToRefreshState = rememberPullToRefreshState()
                    val motion = MaterialTheme.motionScheme
                    Box(Modifier.fillMaxSize()) {
                        PullToRefreshBox(
                            isRefreshing = bunnyRefreshing,
                            onRefresh = {
                                pulledToRefresh = true
                                vm.refresh()
                            },
                            state = pullToRefreshState,
                            modifier = Modifier.fillMaxSize().padding(top = innerPadding.calculateTopPadding()),
                            indicator = {
                                BunnyRefreshIndicator(
                                    state = pullToRefreshState,
                                    isRefreshing = bunnyRefreshing,
                                    modifier = Modifier.align(Alignment.TopCenter),
                                )
                            },
                        ) {
                            MaxWidthContent(innerPadding, extraBottom = floatingBarSpace) { contentPadding ->
                                // Inside the refresh box so the app bar expands before an overscroll becomes a refresh.
                                AnimatedContent(
                                    modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection).belowBunnyRefresh(pullToRefreshState),
                                    targetState = selectedTab,
                                    transitionSpec = { fadeIn(motion.defaultEffectsSpec()) togetherWith fadeOut(motion.fastEffectsSpec()) },
                                    label = "tab",
                                ) { tab ->
                                    tabStates.SaveableStateProvider(tab.name) {
                                        when (tab) {
                                            Tab.HOME -> HomeScreen(state, vm, contentPadding) { selectedTab = it }
                                            Tab.BANDS -> BandsScreen(state, vm, contentPadding)
                                            Tab.CELL -> CellScreen(state, vm, contentPadding)
                                            Tab.TOOLS -> ToolsScreen(state, vm, contentPadding)
                                            Tab.SETTINGS -> SettingsScreen(state, vm, contentPadding)
                                        }
                                    }
                                }
                            }
                        }
                        if (showFloatingBar) {
                            FloatingTabBar(
                                selected = selectedTab,
                                onSelect = { selectedTab = it },
                                modifier =
                                    Modifier.align(Alignment.BottomCenter).padding(
                                        start = innerPadding.calculateStartPadding(layoutDirection) + 16.dp,
                                        end = innerPadding.calculateEndPadding(layoutDirection) + 16.dp,
                                        bottom = innerPadding.calculateBottomPadding() + FloatingToolbarDefaults.ScreenOffset,
                                    ),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MaxWidthContent(
    innerPadding: PaddingValues,
    extraBottom: Dp,
    content: @Composable (contentPadding: PaddingValues) -> Unit,
) {
    val layoutDirection = LocalLayoutDirection.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val start = innerPadding.calculateStartPadding(layoutDirection)
        val end = innerPadding.calculateEndPadding(layoutDirection)
        val gutter = ((maxWidth - start - end - MAX_CONTENT_WIDTH) / 2).coerceAtLeast(0.dp)
        content(PaddingValues(start = start + gutter, end = end + gutter, bottom = innerPadding.calculateBottomPadding() + extraBottom))
    }
}

@Composable
private fun UpdateDialog(
    release: Release,
    onSkip: () -> Unit,
    onDismiss: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.shell_update_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.shell_update_message, release.version))
                if (release.notes.isNotEmpty()) Text(release.notes, style = MaterialTheme.typography.bodyMedium)
            }
        },
        confirmButton = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = {
                        runCatching { uriHandler.openUri(release.url) }
                        onDismiss()
                    },
                    shapes = ButtonDefaults.shapes(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(stringResource(R.string.shell_update_download)) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onSkip, shapes = ButtonDefaults.shapes()) { Text(stringResource(R.string.shell_update_skip)) }
                    TextButton(onClick = onDismiss, shapes = ButtonDefaults.shapes()) { Text(stringResource(R.string.shell_update_later)) }
                }
            }
        },
    )
}

@Composable
private fun LiveRefresh(vm: MainViewModel) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) {
                vm.refreshConnection()
                delay(LIVE_REFRESH_PAUSE)
            }
        }
    }
}

@Composable
private fun topBarSubtitle(state: UiState): String {
    val throughShizuku = state.modem.access == Access.SHIZUKU_ADB || state.modem.access == Access.SHIZUKU_ROOT
    val purpose = stringResource(state.modem.backend?.label ?: R.string.shell_subtitle_default)
    return if (throughShizuku) stringResource(R.string.shell_subtitle_shizuku, purpose) else purpose
}

/** [selected] counts from 1. */
@Composable
private fun SimChip(
    sims: List<SimInfo>,
    selected: Int,
    enabled: Boolean,
    onSelect: (Int) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val current = sims.firstOrNull { it.slot + 1 == selected } ?: return
    val chipDescription = stringResource(R.string.shell_sim_chip_description, selected, current.name)
    Box {
        FilledTonalButton(
            onClick = { expanded = true },
            enabled = enabled,
            shapes = ButtonDefaults.shapes(),
            contentPadding = PaddingValues(start = 8.dp, end = 6.dp),
            modifier = Modifier.semantics { contentDescription = chipDescription },
        ) {
            SimNumber(selected)
            Spacer(Modifier.width(8.dp))
            Text(current.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 120.dp))
            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            sims.forEach { sim ->
                val number = sim.slot + 1
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.shell_sim_menu_item, number, sim.name)) },
                    leadingIcon = { SimNumber(number) },
                    trailingIcon = { if (number == selected) Icon(Icons.Rounded.Check, contentDescription = stringResource(R.string.shell_sim_selected)) },
                    onClick = {
                        expanded = false
                        if (number != selected) onSelect(number)
                    },
                )
            }
        }
    }
}

@Composable
private fun SimNumber(number: Int) {
    val colors = MaterialTheme.colorScheme
    val container = if (number == 1) colors.primary else colors.tertiary
    val content = if (number == 1) colors.onPrimary else colors.onTertiary
    Box(Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(container), contentAlignment = Alignment.Center) {
        Text("$number", color = content, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun Centered(
    innerPadding: PaddingValues,
    content: @Composable () -> Unit,
) {
    Box(Modifier.fillMaxSize().padding(innerPadding).padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            content()
        }
    }
}

@Composable
fun PaddingValues.withScreenMargins(extraBottom: Dp = 0.dp): PaddingValues {
    val layoutDirection = LocalLayoutDirection.current
    return PaddingValues(
        start = calculateStartPadding(layoutDirection) + 16.dp,
        end = calculateEndPadding(layoutDirection) + 16.dp,
        top = calculateTopPadding() + 4.dp,
        bottom = calculateBottomPadding() + 24.dp + extraBottom,
    )
}
